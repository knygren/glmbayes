# glmbayes 0.1.0

Released: 2025-07-14

- CRAN-ready beta version
- S3 interface: `glmb()`, `summary()`, `predict()`, `confint()`
- Vignettes comparing `glmb` with base R `glm()`
- Zero R CMD check notes/errors/warnings
famfunc<-glmbfamfunc(binomial(logit))

print(famfunc)

f1<-famfunc$f1
f2<-famfunc$f2
f3<-famfunc$f3
f5<-famfunc$f5
f6<-famfunc$f6
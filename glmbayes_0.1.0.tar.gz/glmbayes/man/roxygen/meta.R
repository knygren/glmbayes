
list(
  rd_family_title = list(simfuncs = "Other family simulation functions:",
                         modelfuns= "Other glmbayes modeling functions:",
                         pfamilies= "Other pfamily Objects:",
                         prior ="Other prior utility Functions:",
                         data = "Other package datasets:"
                         )
)